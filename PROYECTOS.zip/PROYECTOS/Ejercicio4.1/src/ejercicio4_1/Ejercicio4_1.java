package ejercicio4_1;

import java.util.Scanner;

public class Ejercicio4_1 {

	private int[] miArray = new int[10];
	Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		Ejercicio4_1 ejercicio04 = new Ejercicio4_1();

		ejercicio04.pedirDatos();
		ejercicio04.comprobarOrden();
	}

	private void comprobarOrden() {
		boolean creciente = false;
		boolean decreciente = false;

		for (int i = 0; i < miArray.length - 1;) {
			if (miArray[i] < miArray[++i]) {
				creciente = true;
			} else {
				decreciente = true;
			}
		}

		if (creciente && !decreciente) {
			System.out.println("El array esta creciente");
		} else if (decreciente && !creciente) {
			System.out.println("El array esta decreciente");
		} else if (!creciente && !decreciente) {
			System.out.println("Los numeros son iguales");
		} else {
			System.out.println("El array esta desordenado");
		}
	}

	private void pedirDatos() {
		for (int i = 0; i < miArray.length; i++) {
			System.out.println("Introduce un numero: (Quedan " + (miArray.length - i) + ")");
			miArray[i] = teclado.nextInt();
		}
	}
}
