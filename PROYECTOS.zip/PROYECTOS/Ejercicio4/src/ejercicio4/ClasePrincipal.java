package ejercicio4;

public class ClasePrincipal {

    private Persona[] listado = new Persona[5];

    public static void main(String[] args) {
        ClasePrincipal clasePrincipal = new ClasePrincipal();
        clasePrincipal.inicializarListado();
        
        Listado listado = new Listado();
        listado.mostrarInformacion(clasePrincipal.listado);
    }

    private void inicializarListado() {
        listado[0] = new Persona(5, "Juan");
        listado[1] = new Persona(18, "Pedro");
        listado[2] = new Persona(12, "Luis");
        listado[3] = new Persona(15, "Maria");
        listado[4] = new Persona(20, "Ana");
    }
    
}
