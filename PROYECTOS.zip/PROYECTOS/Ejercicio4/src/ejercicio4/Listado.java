package ejercicio4;

public class Listado {

    public void mostrarInformacion(Persona[] listado) {
        for (int i = 0; i < listado.length; i++) {
            System.out.println("Nombre: " + listado[i].getNombre());
            System.out.println("Edad: " + listado[i].getEdad());
            if (listado[i].getEdad() >= 18) {
                System.out.println("* " + listado[i].getNombre() + " es mayor de edad *");
            } else {
                System.out.println("* " + listado[i].getNombre() + " es menor de edad *");
            }
        }
    }
}
