package paquete;

public class Hija extends Padre{
    
    private String name;
    private int age;
    private String color;

    public Hija(String name, int age, String color) {
        super(name, age);
        this.name = name;
        this.age = age;
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void print() {
        System.out.println("Name: " + name + " Age: " + age + " Color: " + color);
        super.print();
        System.out.println(super.toString());
    }

    public String toString() {
        return "Name: " + name + " Age: " + age + " Color: " + color;
    }
    
}
