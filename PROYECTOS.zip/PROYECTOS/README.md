# INTRUCCIONES DE USO:

## OPCIÓN 1:

* Entrar en el nombre del Proyecto > src > (Nombre del Ejercicio) > (Ejercicio.java)
* Copiar el contenido de la clase.
* Pegar en la clase ya creada dentro del Eclipse
* Como añadido se pueden cambiar los nombres de variables/métodos etc
* Comprobar que funciona el ejercicio.

## OPCIÓN 2:

* Pinchar en el cuadrado verde CODE
* Download ZIP
* Extraer el ZIP en nuestro equipo
* Abrir Eclipse > File > Import > General > Existing Projects into Workspace > Next
* En la parte de arriba a la derecha elegimos la carpeta extraída
* Seleccionamos los proyectos a importar
* Seleccionamos Finish
