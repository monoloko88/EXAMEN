package src.ejer_01;

import java.util.Scanner;

public class Ejer_01 {

	/*
	 * Pedir que se introduzca un n�mero y mostrar su cuadrado, hasta que se
	 * introduzca un n�mero negativo.
	 */

	private static int numero = 0;
	
	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		metodo01();
	}

	private static void metodo01() {
		System.out.println(
				"EJERCICIO QUE MUESTRA EL CUADRADO DE UN N�MERO INTRODUCIDO POR TECLADO. UN N�MERO NEGATIVO FINALIZA EL PROGRAMA.");

		while (numero >= 0) {
			System.out.println("Introducir un n�mero.");
			numero = teclado.nextInt();
			System.out.println("El cuadrado del n�mero " + numero + " es: " + (int) Math.pow(numero, 2));
		}

		teclado.close();

		System.out.println("EL PROGRAMA HA FINALIZADO.");
	}

}
