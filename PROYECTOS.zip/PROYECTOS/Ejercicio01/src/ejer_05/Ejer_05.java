package src.ejer_05;

public class Ejer_05 {

	/*
	 * Necesitamos mostrar un contador con 5 d�gitos (X-X-X-X-X), que muestre los
	 * n�meros del 0-0-0-0-0 al 9-9-9-9-9, con la particularidad que cada vez que
	 * aparezca un 3 lo sustituya por una E.
	 */

	public static void main(String[] args) {
		metodo01();
	}

	private static void metodo01() {
		System.out.println(
				"EJERCICIO QUE MUESTRA DESDE EL 0-0-0-0-0 AL 9-9-9-9-9 Y SUSTITUYE EL N�MERO [3] POR LA LETRA [E].");

		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				for (int k = 0; k < 10; k++) {
					for (int l = 0; l < 10; l++) {
						for (int m = 0; m < 10; m++) {
							if (i != 3) {
								System.out.print(i + "-");
							} else {
								System.out.print("E" + "-");
							}
							if (j != 3) {
								System.out.print(j + "-");
							} else {
								System.out.print("E" + "-");
							}
							if (k != 3) {
								System.out.print(k + "-");
							} else {
								System.out.print("E" + "-");
							}
							if (l != 3) {
								System.out.print(l + "-");
							} else {
								System.out.print("E" + "-");
							}
							if (m != 3) {
								System.out.print(m);
							} else {
								System.out.print("E");
							}
							System.out.println();
						}
					}
				}
			}
		}
		System.out.println("EL PROGRAMA HA FINALIZADO.");
	}

}
