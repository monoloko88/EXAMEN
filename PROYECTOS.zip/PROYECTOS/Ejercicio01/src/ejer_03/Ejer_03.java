package src.ejer_03;

import java.util.Scanner;

public class Ejer_03 {

	/*
	 * Pedir 10 n�meros. Mostrar la media de los n�meros positivos, la media de los
	 * n�meros negativos y la cantidad de ceros introducidos.
	 */

	private static float mediaPositivos = 0;
	private static float mediaNegativos = 0;
	private static int ceros = 0;
	
	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		metodo01();
	}

	private static void metodo01() {
		int numero = 0;
		System.out.println(
				"EJERCICIO PIDE 10 N�MEROS Y CALCULA LA MEDIA DE LOS POSITIVOS, LA MEDIA DE LOS NEGATIVOS Y EL N�MERO DE CEROS INTRODUCIDOS.");

		int contador1 = 0;
		int contador2 = 0;

		for (int i = 0; i < 10; i++) {
			System.out.println("Quedan " + (10 - i) + " n�meros por introducir.");
			numero = teclado.nextInt();

			if (numero > 0) {
				mediaPositivos += numero;
				contador1++;
			} else if (numero < 0) {
				mediaNegativos += numero;
				contador2++;
			} else {
				ceros++;
			}
		}

		if (contador1 != 0)
			System.out.println("La media de los n�meros positivos es: " + (mediaPositivos / contador1));
		if (contador2 != 0)
			System.out.println("La media de los n�meros negativos es: " + (mediaNegativos / contador2));

		System.out.println("El n�mero de ceros introducidos es: " + ceros);

		teclado.close();

		System.out.println("EL PROGRAMA HA FINALIZADO.");
	}

}
