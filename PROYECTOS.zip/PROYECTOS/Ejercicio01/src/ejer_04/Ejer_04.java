package src.ejer_04;

import java.util.Scanner;

public class Ejer_04 {

	/*
	 * Pedir 5 calificaciones de alumnos y decir al final el n�mero de suspensos y
	 * la nota media.
	 */

	private static int suspensos = 0;
	private static float notaMedia = 0;

	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		metodo01();
	}

	private static void metodo01() {
		float calificacion = 0;
		System.out.println(
				"EJERCICIO QUE PIDE 5 CALIFICACIONES E INDICA EL N�MERO DE SUSPENSOS Y LA NOTA MEDIA DE LAS CALIFICACIONES.");

		for (int i = 1; i <= 5; i++) {
			System.out.println("Introducir la calificaci�n n�mero: " + i);
			calificacion = teclado.nextFloat();
			if (calificacion >= 0 && calificacion <= 10) {
				if (calificacion < 5) {
					suspensos++;
				}
				notaMedia += calificacion;
			} else {
				System.out.println("La nota introducida se sale de los valores permitidos.");
				i--;
			}
		}

		System.out.println("La nota media de las calificaciones es de: " + (notaMedia / 5));
		System.out.println("Ha habido " + suspensos + " suspensos.");

		teclado.close();

		System.out.println("EL PROGRAMA HA FINALIZADO.");
	}

}
