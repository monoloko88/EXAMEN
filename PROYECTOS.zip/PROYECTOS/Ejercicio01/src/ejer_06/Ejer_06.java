package src.ejer_06;

import java.util.Scanner;

public class Ejer_06 {

	/*
	 * Leer un n�mero e indicar si es par o impar. El proceso se repetir� hasta que
	 * se introduzca un 0.
	 */

	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		metodo01();
	}

	private static void metodo01() {
		int numero = 0;
		System.out.println(
				"EJERCICIO QUE LEE UN N�MERO E INDICA SI ES PAR O IMPAR. EL PROGRAMA FINALIZA AL INSERTAR UN 0.");

		do {
			System.out.println("Introduzca un n�mero.");
			numero = teclado.nextInt();

			if (numero != 0) {
				if (numero % 2 == 0) {
					System.out.println("El n�mero " + numero + " es par.");
				} else {
					System.out.println("El n�mero " + numero + " es impar.");
				}

			}
		} while (numero != 0);

		teclado.close();

		System.out.println("EL PROGRAMA HA FINALIZADO.");
	}

}
