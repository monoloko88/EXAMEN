package src.ejer_07;

import java.util.Random;
import java.util.Scanner;

public class Ejer_07 {

	/*
	 * Tenemos un n�mero aleatorio N. El programa pedir� n�meros, indicando "mayor"
	 * o "menor" seg�n sea el n�mero respecto a N. El proceso termina cuando el
	 * usuario acierta o ha agotado los intentos. Tendr� cinco intentos. Haced el
	 * programa con un bucle while.
	 */

	private static int intentos = 5;

	private static Random aleatorio = new Random();
	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		metodo01();
	}

	private static void metodo01() {
		int random = 0;
		int numero = 0;
		System.out.println(
				"EJERCICIO QUE GENERA UN N�MERO ALEATORIO Y PIDE N�MEROS POR TECLADO DANDO PISTAS PARA ACERTARLO. 5 INTENTOS.");

		random = aleatorio.nextInt(101 - 0) + 0;

		System.out.println("Por favor introduzca un n�mero entre 0 y 100.");
		while (intentos > 0) {

			numero = teclado.nextInt();
			intentos--;

			if (random > numero) {
				System.out.println("El n�mero elegido es MENOR que el n�mero aleatorio.");
				System.out.println("Te quedan " + intentos + " intentos.");
			} else if (random < numero) {
				System.out.println("El n�mero elegido es MAYOR que el n�mero aleatorio.");
				System.out.println("Te quedan " + intentos + " intentos.");
			} else {
				System.out.println("FELICIDADES! Has acertado el n�mero.");
				break;
			}
			if (intentos == 0) {
				System.out.println("El n�mero aleatorio era: " + random);
			}
		}

		teclado.close();

		System.out.println("EL PROGRAMA HA FINALIZADO.");
	}

}
