package src.ejer_02;

import java.util.Scanner;

public class Ejer_02 {

	/*
	 * Pedir que se introduzcan 15 n�meros y escribir la suma total.
	 */

	private static int numero = 0;
	
	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		metodo01();
	}

	private static void metodo01() {
		System.out.println("EJERCICIO QUE PIDE 15 N�MEROS POR TECLADO Y REALIZA SU SUMA.");

		for (int i = 0; i < 15; i++) {
			System.out.println("Quedan " + (15 - i) + " n�meros por introducir.");
			numero += teclado.nextInt();
		}

		System.out.println("La suma de todos los n�meros introducidos es: " + numero);

		teclado.close();

		System.out.println("EL PROGRAMA HA FINALIZADO.");
	}

}
