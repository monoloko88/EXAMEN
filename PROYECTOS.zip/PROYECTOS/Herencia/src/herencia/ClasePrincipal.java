package herencia;

public class ClasePrincipal {

	public static void main(String[] args) {
		Alumno alumno = new Alumno("Julio", 25, 7);
		alumno.informacion();
	}

}
