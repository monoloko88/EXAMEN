package paqueteDos;

import paqueteUno.Aleatorio;

public class NumeroEjemplo extends Aleatorio {

	public void mostrar() {
		numeroAleatorio();
	}

}
