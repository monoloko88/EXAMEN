package paqueteUno;

import paqueteDos.NumeroEjemplo;

public class Principal {

	public static void main(String[] args) {
		NumeroEjemplo coso = new NumeroEjemplo();
		coso.mostrar();
	}

}
