package banco;

import java.util.Random;

public class CuentaCorriente {
	private double saldo;
	private String nombreTitular;
	private long numeroCuenta;
	private Random aleatorio = new Random();

	public CuentaCorriente(double s, String n) {
		saldo = s;
		nombreTitular = n;

		numeroCuenta = aleatorio.nextLong(Long.MAX_VALUE);
	}

	public void ingreso(double d, boolean b) {
		if (d > 0) {
			saldo += d;
			System.out.println("El saldo de su cuenta ha sido actualizado.");
			if(b)
			System.out.printf("Actualmente tiene %.2f€ en su cuenta corriente.\n",saldo);
		} else {
			System.out.println("No ha podido ser actualizado el saldo de su cuenta corriente.");
		}
	}

	public void reintegro(double d) {
		if (saldo > 0) {
			if (d > 0 && d < saldo) {
				saldo -= d;
				System.out.println("El saldo de su cuenta ha sido actualizado.");
				System.out.printf("Actualmente tiene %.2f€ en su cuenta corriente.\n",saldo);
			} else {
				System.out.println("No tiene saldo suficiente en su cuenta corriente.");
			}
		} else {
			System.out.println("No ha podido ser actualizado el saldo de su cuenta corriente.");
		}
	}

	public double getSaldo() {
		return saldo;
	}

	public long getNumeroCuenta() {
		return numeroCuenta;
	}

	public void informacionGeneral() {
		System.out.println("INFORMACIÓN RELATIVA A SU CUENTA CORRIENTE");
		System.out.println("Nombre del Titular: " + nombreTitular);
		System.out.println("Número de cuenta: " + numeroCuenta);
		System.out.println("Saldo Total: " + saldo);
	}

	public void transferencia(CuentaCorriente cuenta, double s) {
		if (saldo > s) {
			cuenta.ingreso(s,false);
			saldo -= s;
			System.out.println("Se ha realizado una transferencia de " + s + "€.");
		} else {
			System.out.println("No hay suficiente saldo en su cuenta corriente.");
		}
	}

}
