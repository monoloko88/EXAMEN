package banco;

import java.util.Scanner;

public class ClasePrincipal {
	private static Scanner teclado = new Scanner(System.in);

	private static CuentaCorriente cuenta1;
	private static CuentaCorriente cuenta2;

	private static String nombre;
	private static double saldo;
	private static int opcion;

	public static void main(String[] args) {
		System.out.println("Bienvenido al Banco");
		System.out.println("A continuaci�n procederemos a crear las dos cuentas corrientes.");

		for (int i = 0; i < 2; i++) {
			do {
				System.out.println("Introduzca el nombre del titular:");
				nombre = teclado.next();
			} while (nombre == "");

			do {
				System.out.println("Introduzca el saldo inicial de la cuenta:");
				saldo = teclado.nextDouble();
			} while (saldo < 0);

			if (i == 0) {
				cuenta1 = new CuentaCorriente(saldo, nombre);
				System.out.println("Cuenta n�mero 1 creada.");
			} else {
				cuenta2 = new CuentaCorriente(saldo, nombre);
				System.out.println("Cuenta n�mero 2 creada.");
			}
		}

		do {
			System.out.println("-------------------------");
			System.out.println("-------------------------");
			System.out.println("1.- Listar Cuentas.");
			System.out.println("2.- Modificar cuenta.");
			System.out.println("0.- Salir.");
			System.out.println("Indique qu� desea hacer:");
			opcion = teclado.nextInt();

			switch (opcion) {
			case 1:
				System.out.print("Elegir la cuenta de la que quiere obtener la informaci�n: ");
				opcion = teclado.nextInt();

				if (opcion > 0 && opcion < 3) {
					if (opcion == 1) {
						cuenta1.informacionGeneral();
					} else {
						cuenta2.informacionGeneral();
					}
				} else {
					System.out.println("Opci�n No V�lida.");
				}

				break;

			case 2:
				System.out.print("Elegir la cuenta en la que quiere realizar modificaciones:");
				opcion = teclado.nextInt();

				if (opcion > 0 && opcion < 3) {
					System.out.println("Las opciones son: ");
					System.out.println("1.- Realizar Ingreso.");
					System.out.println("2.- Realizar Reintegro.");
					System.out.println("3.- Realizar Transferencia.");
					System.out.println("Elegir una opci�n:");

					if (opcion == 1) {
						opcion = teclado.nextInt();
						switch (opcion) {
						case 1:
							System.out.print("Cu�nto dinero quiere ingresar en la Cuenta1: ");
							saldo = teclado.nextDouble();
							cuenta1.ingreso(saldo,true);
							break;
						case 2:
							System.out.print("Cu�nto dinero quiere sacar de la Cuenta1: ");
							saldo = teclado.nextDouble();
							cuenta1.reintegro(saldo);
							break;
						case 3:
							System.out.print("Cu�nto dinero quiere transferir de la Cuenta1 a la Cuenta2: ");
							saldo = teclado.nextDouble();

							cuenta1.transferencia(cuenta2, saldo);
							break;

						default:
							break;
						}
					} else {
						opcion = teclado.nextInt();
						switch (opcion) {
						case 1:
							System.out.print("Cu�nto dinero quiere ingresar en la Cuenta2: ");
							saldo = teclado.nextDouble();
							cuenta2.ingreso(saldo,true);
							break;
						case 2:
							System.out.print("Cu�nto dinero quiere sacar de la Cuenta2: ");
							saldo = teclado.nextDouble();
							cuenta2.reintegro(saldo);
							break;
						case 3:
							System.out.print("Cu�nto dinero quiere transferir de la Cuenta2 a la Cuenta1: ");
							saldo = teclado.nextDouble();

							cuenta2.transferencia(cuenta1, saldo);
							break;
						default:
							break;
						}
					}
				} else {
					System.out.println("Opci�n No V�lida.");
				}

				break;
			default:
				break;
			}
			if (opcion != 0) {
				opcion = -1;
			}
		} while (opcion < 0 || opcion > 2);

		System.out.println("Gracias por utilizar la aplicaci�n.");

	}

}
