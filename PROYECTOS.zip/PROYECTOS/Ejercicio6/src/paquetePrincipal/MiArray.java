package paquetePrincipal;

import java.util.Scanner;

public class MiArray {
	private int[][][] matriz;
	private Scanner scan = new Scanner(System.in);
	private DesarrolloArray desarrollo = new DesarrolloArray();

	public MiArray() {
		inicializarArray();

		desarrollo.rellenarArray(matriz);
		desarrollo.mostrarArray(matriz);
	}

	private void inicializarArray() {
		int d1 = 0, d2 = 0, d3 = 0;

		System.out.println("Introducir el valor de cada dimension del Array");
		System.out.print("PRIMERA DIMENSION: ");
		d1 = scan.nextInt();
		System.out.print("SEGUNDA DIMENSION: ");
		d2 = scan.nextInt();
		System.out.print("TERCERA DIMENSION: ");
		d3 = scan.nextInt();

		matriz = new int[d1][d2][d3];

		System.out.println("Se ha creado una matriz de 3 dimensiones: [1] = " + d1 + " [2] = " + d2 + " [3] = " + d3);
	}

}
