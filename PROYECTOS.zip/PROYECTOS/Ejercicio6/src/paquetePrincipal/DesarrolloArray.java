package paquetePrincipal;

public class DesarrolloArray {
	private int aux, elementos;

	public void rellenarArray(int[][][] miArray) {
		for (int i = 0; i < miArray.length; i++) {
			for (int j = 0; j < miArray[i].length; j++) {
				for (int k = 0; k < miArray[i][j].length; k++) {
					miArray[i][j][k] = (int) (Math.random() * 10);
				}
			}
		}
	}

	public void mostrarArray(int[][][] miArray) {
		System.out.println("*******************************************");
		System.out.println("Arrays definidos por la primera dimension.");

		for (int i = 0; i < miArray.length; i++) {
			for (int j = 0; j < miArray[i].length; j++) {
				for (int k = 0; k < miArray[i][j].length; k++) {
					System.out.print(miArray[i][j][k]);
					aux += miArray[i][j][k];
				}
			}
			System.out.println();
		}
		
		elementos = miArray.length + miArray[0].length + miArray[0][0].length;
		
		System.out.println("El numero total de elementos es de: " + elementos);
		System.out.println("La media de elementos por dimension es de: " + elementos / 3);
		System.out.println("La media de los valores dentro del array es de: " + aux/elementos);
	}
}
