package paquetePrincipal;

public class ClasePrincipal {

	public static void main(String[] args) {
		MiArray ejercicio = new MiArray();

	}

}
