package paquetePrincipal;

public class Disco extends Articulo {
	
	private String interprete;
	
	public Disco(String nombre, int precio, String interprete) {
		super(nombre, precio);
		this.interprete = interprete;
	}

	public String getInterprete() {
		return interprete;
	}

	public void setInterprete(String interprete) {
		this.interprete = interprete;
	}

	@Override
	public String toString() {
		String info = super.toString() + "\nInterprete: " + getInterprete();
		return info;
	}

}
