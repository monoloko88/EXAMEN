package paquetePrincipal;

public class Principal {

	public static void main(String[] args) {
		principal();
	}

	private static void principal() {
		String informacion;
				
		Libro libro = new Libro("El Principito", 27, "AutorDeLibro");
		
		informacion = libro.toString();
		System.out.println(informacion);
		
		Disco disco = new Disco("Destrangis", 35, "InterpreteDeCancion");
		
		informacion = disco.toString();
		System.out.println(informacion);
	}

}
