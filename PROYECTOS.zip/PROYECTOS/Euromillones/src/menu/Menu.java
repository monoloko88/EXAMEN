package menu;

import java.util.Scanner;

public class Menu {
    private static Scanner scan = new Scanner(System.in);

    public static int menu(){
        int opcion = 0;
        System.out.println("1-. Añadir Apuesta.");
        System.out.println("2-. Visualizar Apuesta.");
        System.out.println("3-. Precio total de la Apuesta.");
        System.out.println("4-. Salir.");
        System.out.print("Elija una opcion: ");
        opcion = scan.nextInt();
        System.out.println("---------------------------------------------------");
        return opcion;
    }
}
