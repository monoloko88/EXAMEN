package principal;

import menu.Menu;
import util.Sorteo;

public class ClasePrincipal {
    private static Sorteo sorteo = new Sorteo();
    private static int opcion;

    public static void main(String[] args) {

        do {
            opcion = Menu.menu();

            switch (opcion) {
                case 1:
                    System.out.println("Añadir Apuesta.");
                    sorteo.addEuromillones();
                    System.out.println("Apuesta procesada correctamente.");
                    System.out.println("***************************************************");
                    break;
                case 2:
                    System.out.println("Visualizar Apuesta.");
                    sorteo.showEuromillones();
                    System.out.println("***************************************************");
                    break;
                case 3:
                    System.out.println("Precio total de la Apuesta.");
                    System.out.println("La apuesta es de: " + sorteo.getTotal() + " euros.");
                    System.out.println("***************************************************");
                    break;
                case 4:
                    System.out.println("Gracias por participar.");
                    break;
                default:
                    System.out.println("Opcion no valida.");
                    System.out.println("***************************************************");
                    break;
            }
        } while (opcion != 4);
    }
}
