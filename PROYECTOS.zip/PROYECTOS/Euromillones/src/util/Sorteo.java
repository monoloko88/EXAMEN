package util;

import java.util.ArrayList;

public class Sorteo {
    private ArrayList<Euromillones> euromillones;
    private int total;

    public Sorteo() {
        euromillones = new ArrayList<Euromillones>();
    }

    public void addEuromillones() {
        if (euromillones.size() < 5) {
            euromillones.add(new Euromillones());
            total += euromillones.iterator().next().getPrecio();
        }
        else {
            System.out.println("No se pueden añadir mas apuestas.");
        }
    }

    public void showEuromillones() {
        if (euromillones.size() == 0) {
            System.out.println("Actualmente no se ha realizado ninguna apuesta.");
        } else {
            System.out.println("Combinaciones Generadas Aleatoriamente:\n");  
            for (int i = 0; i < euromillones.size(); i++) {
                
                euromillones.get(i).muestraCombinacion();
            }
        }
    }

    public int getTotal() {
        return total;
    }

}
