package util;

public class Euromillones {
    private int[] numeros = new int[5];
    private int[] estrellas = new int[2];
    private final int precio = 2;

    public Euromillones() {
        numeros = generaNumeros();
        estrellas = generaEstrellas();
    }

    private int[] generaNumeros() {
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = numeroAleatorio(1, 50);
        }
        return numeros;
    }

    private int[] generaEstrellas() {
        for (int i = 0; i < estrellas.length; i++) {
            estrellas[i] = numeroAleatorio(1, 12);
        }
        return estrellas;
    }

    private int numeroAleatorio(int i, int j) {
        return (int) (Math.random() * (j - i + 1) + i);
    }

    public void muestraCombinacion() {
        System.out.print("Numeros: ");
        for (int i = 0; i < numeros.length; i++) {
            System.out.printf("%2s ", numeros[i]);
        }
        System.out.print("\tEstrellas: ");
        for (int i = 0; i < estrellas.length; i++) {
            System.out.printf("%2s ", estrellas[i]);
        }
        System.out.println();
    }

    public int getPrecio() {
        return precio;
    }

}
