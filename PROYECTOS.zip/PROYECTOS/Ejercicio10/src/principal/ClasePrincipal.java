package principal;

public class ClasePrincipal {
    public static void main(String[] args) {
        Aplicacion aplicacion = new Aplicacion();
        aplicacion.metodo();
    }
}
