package principal;

import util.Menu;

public class Aplicacion {

    public void metodo() {
        Menu menu = new Menu();
        int resultado = 0;

        do {

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            resultado = menu.metodo();
        } while (resultado != 5);

    }

}
