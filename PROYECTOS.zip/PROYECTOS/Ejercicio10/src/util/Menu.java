package util;

import java.util.Scanner;

public class Menu {
    private Scanner scan = new Scanner(System.in);
    private Opciones opciones = new Opciones();
    private int opcion;

    public int metodo() {
        System.out.println("*********TALLER DE VEHICULOS************");
        System.out.println("1_ Listado de Vehiculos.");
        System.out.println("2_ Agregar Vehiculo.");
        System.out.println("3_ Buscar Vehiculo.");
        System.out.println("4_ Vehiculo Reparado.");
        System.out.println("5_ Salir.");
        System.out.println("*********TALLER DE VEHICULOS************");

        System.out.print("Ingrese una opción: ");
        opcion = scan.nextInt();
        System.out.println("----------------------------------------");
        opciones.opcion(opcion);
        return opcion;
    }
}
