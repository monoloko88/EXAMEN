package util;

import java.util.ArrayList;
import java.util.Scanner;

import listado.FichaVehiculos;
import listado.ListadoVehiculos;

public class Opciones {
    private ArrayList<FichaVehiculos> listaVehiculos = new ArrayList<FichaVehiculos>();
    private ListadoVehiculos listadoVehiculos = new ListadoVehiculos();
    private Scanner scan = new Scanner(System.in);
    private String modelo;
    private String matricula;

    public Opciones() {
        listaVehiculos.add(new FichaVehiculos(1, "Ford", "ABC123"));
        listaVehiculos.add(new FichaVehiculos(2, "Fiat", "DEF456"));
    }

    protected void opcion(int opcion) {
        switch (opcion) {
            case 1:
                listadoVehiculos.listarVehiculos(listaVehiculos);
                break;
            case 2:
                System.out.println("Agregar Vehiculo");
                System.out.println("Ingrese el modelo del vehiculo");
                modelo = scan.next();
                System.out.println("Ingrese la matricula del vehiculo");
                matricula = scan.next();

                listadoVehiculos.agregarVehiculo(listaVehiculos, modelo, matricula);
                break;
            case 3:
                System.out.println("Buscar Vehiculo");
                System.out.println("Ingrese la matricula del vehiculo");
                matricula = scan.next();
                listadoVehiculos.buscarVehiculo(listaVehiculos, matricula);
                break;
            case 4:
                System.out.println("Vehiculo Reparado");
                System.out.println("Ingrese la matricula del vehiculo");
                matricula = scan.next();

                listadoVehiculos.repararVehiculo(listaVehiculos, matricula);
                break;
            case 5:
                System.out.println("Gracias por utilizar el programa.");
                break;
            default:
                System.out.println("Opción no válida.");
                break;
        }
    }
    
}
