package listado;

public class FichaVehiculos {
    private int id;
    private String modelo;
    private String matricula;
    private boolean reparado;

    public FichaVehiculos(int id, String modelo, String matricula) {
        this.id = id;
        this.modelo = modelo;
        this.matricula = matricula;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public boolean isReparado() {
        return reparado;
    }

    public void setReparado(boolean reparado) {
        this.reparado = reparado;
    }

}
