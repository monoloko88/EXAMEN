package listado;

import java.util.ArrayList;
import java.util.Iterator;

public class ListadoVehiculos {
    private boolean existe;

    public void listarVehiculos(ArrayList<FichaVehiculos> listaVehiculos) {
        System.out.println("Listado de Vehiculos");
        Iterator<FichaVehiculos> it = listaVehiculos.iterator();
        while (it.hasNext()) {
            FichaVehiculos fichaVehiculos = it.next();
            System.out.println("ID: " + fichaVehiculos.getId());
            System.out.println("Modelo: " + fichaVehiculos.getModelo());
            System.out.println("Matricula: " + fichaVehiculos.getMatricula());
            System.out.println("Reparado: " + fichaVehiculos.isReparado());
            System.out.println("");
        }

    }

    public void agregarVehiculo(ArrayList<FichaVehiculos> listaVehiculos, String modelo, String matricula) {
        System.out.println("----------------------------------------");
        listaVehiculos.add(new FichaVehiculos(listaVehiculos.size() + 1, modelo.toUpperCase(), matricula.toUpperCase()));
        System.out.println("Vehiculo agregado.");
        System.out.println("");
    }

    public void buscarVehiculo(ArrayList<FichaVehiculos> listaVehiculos, String matricula) {
        for (FichaVehiculos fichaVehiculos : listaVehiculos) {
            if (fichaVehiculos.getMatricula().equals(matricula.toUpperCase())) {
                System.out.println("----------------------------------------");
                System.out.println("ID: " + fichaVehiculos.getId());
                System.out.println("Modelo: " + fichaVehiculos.getModelo());
                System.out.println("Matricula: " + fichaVehiculos.getMatricula());
                System.out.println("Reparado: " + fichaVehiculos.isReparado());
                existe = true;
                break;
            }else{
                existe = false;
            }
        }
        if (!existe) {
            System.out.println("No se encontró el vehiculo.");
        }
        System.out.println("");
    }

    public void repararVehiculo(ArrayList<FichaVehiculos> listaVehiculos, String matricula) {
        for (FichaVehiculos fichaVehiculos : listaVehiculos) {
            if (fichaVehiculos.getMatricula().equals(matricula.toUpperCase())) {
                System.out.println("----------------------------------------");
                fichaVehiculos.setReparado(true);
                System.out.println("Vehiculo reparado.");
                existe = true;
                break;
            }else{
                existe = false;
            }
        }
        if (!existe) {
            System.out.println("No se encontró el vehiculo.");
        }
        System.out.println("");
    }

}
