package miPaquete;

public class Principal {

	public static void main(String[] args) {
		AlumnoUno ejercicio = new AlumnoUno();
		ejercicio.mostrarAlumnos();
	}

}
