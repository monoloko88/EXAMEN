package miPaquete;

import java.util.Scanner;

public class AlumnoDos {
	
	private Scanner scan = new Scanner(System.in);
	private String nombre;
	
	public Alumno seleccionarAlumno(Alumno[] alumno01) {
		
		System.out.print("Introducir nombre del alumno que quiere seleccionar: ");
		nombre = scan.next();
		
		for (Alumno alumno : alumno01) {
			if(alumno.getNombre().equals(nombre)) {
				return alumno;
			}else {
				System.out.println("El alumno no existe.");
			}
		}
		return null;
	}
	
	
	
	
}
