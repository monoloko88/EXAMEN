package miPaquete;

import java.util.Scanner;

public class AlumnoUno {
	
	private Scanner teclado = new Scanner(System.in);
	private Alumno[] alumnos = new Alumno[3];
	private String nombre;
	private float nota;
	private Alumno alumno;
	private AlumnoDos alumnoDos = new AlumnoDos();
	
	public void crearAlumnos() {
		
		for (Alumno alumno : alumnos) {
			System.out.print("Introducir el nombre del alumno:");
			nombre = teclado.next();
			
			System.out.print("Introducir la nota del alumno:");
			nota = teclado.nextFloat();
			
			alumno = new Alumno(nombre, nota);
		}
	}
	
	public void mostrarAlumnos() {
		crearAlumnos();
		alumno = alumnoDos.seleccionarAlumno(alumnos);
		
		if(alumno != null) {
			System.out.println(alumno.getNombre());
			System.out.println(alumno.getNota());
		}else {
			System.out.println("No existe.");
		}
	}
	
}
