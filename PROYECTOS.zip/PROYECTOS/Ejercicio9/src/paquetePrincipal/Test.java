package paquetePrincipal;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        ListaCantantesFamosos listaCantantesFamosos = new ListaCantantesFamosos();
        Scanner scan = new Scanner(System.in);
        int opcion = 0;
        String nombre;
        String discoConMasVentas;

        System.out.println("Indique la opcion que desea realizar:");
        do {
            System.out.println("1. Agregar cantante famoso.");
            System.out.println("2. Mostrar lista actualizada.");
            System.out.println("0. Salir.");
            System.out.print("Ingrese una opcion: ");
            opcion = scan.nextInt();
            scan.nextLine();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el nombre del cantante: ");
                    nombre = scan.nextLine();
                    System.out.println("Ingrese el disco con mas ventas: ");
                    discoConMasVentas = scan.nextLine();

                    listaCantantesFamosos.add(new CantanteFamoso(nombre, discoConMasVentas));
                    break;
                case 2:
                	listaCantantesFamosos.mostrarLista();
                	break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    break;
            }
        } while (opcion != 0);

        //scan.close();
    }

}
