package paquetePrincipal;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaCantantesFamosos {
    private ArrayList<CantanteFamoso> listaCantantesFamosos = new ArrayList<CantanteFamoso>();

    public ListaCantantesFamosos() {
        listaCantantesFamosos.add(new CantanteFamoso("Madonna", "All I want is you"));
        listaCantantesFamosos.add(new CantanteFamoso("Jorge Negrete", "Jalisco"));

        System.out.println("La lista inicial contiene los siguientes datos:");
        for (CantanteFamoso cantanteFamoso : listaCantantesFamosos) {
            System.out.println(cantanteFamoso.getNombre() + " - " + cantanteFamoso.getDiscoConMasVentas());
        }
    }

    public void add(CantanteFamoso cantanteFamoso) {
        listaCantantesFamosos.add(cantanteFamoso);
        System.out.println("Cantante agregado");
    }
    
    public void mostrarLista() {
    	System.out.println("**************************************************");
        System.out.println("La lista actual contiene los siguientes datos:");
        
        Iterator<CantanteFamoso> iterator = listaCantantesFamosos.iterator();
        while (iterator.hasNext()) {
            CantanteFamoso cantanteFamosoIt = iterator.next();
            System.out.println(cantanteFamosoIt.getNombre() + " - " + cantanteFamosoIt.getDiscoConMasVentas());
        }
        System.out.println("--------------------------------------------------");
        
//        for (CantanteFamoso cantanteFamoso2 : listaCantantesFamosos) {
//        	System.out.println(cantanteFamoso2.getNombre() + " - " + cantanteFamoso2.getDiscoConMasVentas());
//		}
    }
}
