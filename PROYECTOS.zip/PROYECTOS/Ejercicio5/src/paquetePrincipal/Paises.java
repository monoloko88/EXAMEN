package paquetePrincipal;

import java.util.Scanner;

public class Paises {
	
	private Scanner teclado = new Scanner(System.in);
	
	
	public void rellenarMatriz(String[][] paisCiudad) {
		
		System.out.println("A continuacion vamos a rellenar la matriz.");
		System.out.println("Introduzca el nombre del pais y tres ciudades.");
		
		for (int i = 0; i < paisCiudad.length; i++) {
			System.out.println("Introduzca el nombre de un pais.");
			paisCiudad[0][i] = teclado.next();
		}
		
		for (int i = 0; i < paisCiudad[0].length; i++) {
			System.out.println("Introduzca el nombre de una ciudad.");
			paisCiudad[0][i] = teclado.next();
		}
		
		
		
		
//		for (String[] pais : paisCiudad) {
//			System.out.println("Introduzca el nombre de cuatro paises.");
//			pais[0] = teclado.next();
//			for (String ciudad : pais) {
//				System.out.println("Faltan "+(3-1+ " ciudades por introducir."));
//				ciudad = teclado.next();
//			}
//		}
	}
	
	public void mostrarMatriz(String[][] paisCiudad) {
		for (String[] pais : paisCiudad) {
			for (String ciudad : pais) {
				System.out.println(ciudad);
			}
		}
	}
	
}
