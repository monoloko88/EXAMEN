package paquetePrincipal;

public class ClasePrincipal {

	private static String[][] paisCiudad = new String[4][3];
	
	public static void main(String[] args) {
		Paises ejercicio = new Paises();
		ejercicio.rellenarMatriz(paisCiudad);
		
		ejercicio.mostrarMatriz(paisCiudad);

	}

}
