package principal;

import java.util.Scanner;

import alumno.FichaAlumno;
import alumno.Menu;

public class LlamadaMenu {
    public void crearMenu() {
        Menu menu = new Menu();
        FichaAlumno ficha = new FichaAlumno();
        Scanner scan = new Scanner(System.in);
        int opcion = 0;

        do {
            menu.monstrarMenu();
            System.out.println("Introduzca una opcion.");
            opcion = scan.nextInt();

            switch (opcion) {
            case 1:
                System.out.println("Introduzca el nombre del alumno.");
                String nombre = scan.next();
                System.out.println("Introduzca la nota del alumno.");
                int nota = scan.nextInt();
                ficha.agregarAlumno(nombre, nota);
                break;
            case 2:
                System.out.println("Introduzca el nombre del alumno.");
                nombre = scan.next();
                ficha.eliminarAlumno(nombre);
                break;
            case 3:
                System.out.println("Introduzca el nombre del alumno.");
                nombre = scan.next();
                ficha.buscarAlumno(nombre);
                break;
            case 4:
            ficha.numeroAlumnos();
                break;
            case 0:
                System.out.println("Gracias por usar el programa.");
                break;
            default:
                System.out.println("Opcion no valida.");
                break;
            }

            System.out.println("*****************************************");
        } while (opcion != 0);
        scan.close();
    }
}
