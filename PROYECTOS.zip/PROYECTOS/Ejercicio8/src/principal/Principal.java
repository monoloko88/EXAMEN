package principal;

public class Principal {
    public static void main(String[] args) {
        LlamadaMenu llamada = new LlamadaMenu();
        llamada.crearMenu();
    }
}
