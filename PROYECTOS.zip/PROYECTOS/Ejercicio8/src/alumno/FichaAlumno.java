package alumno;

import java.util.ArrayList;

public class FichaAlumno {
    ArrayList<Alumno> clase = new ArrayList<Alumno>();

    public void agregarAlumno(String nombre, int nota) {
        Alumno alumno = new Alumno(nombre, nota);
        clase.add(alumno);
        System.out.println("Alumno agregado.");
    }

    public void eliminarAlumno(String nombre) {
        for (int i = 0; i < clase.size(); i++) {
            if (clase.get(i).getNombre().equals(nombre)) {
                clase.remove(i);
                System.out.println("Alumno eliminado.");
            }else{
                System.out.println("No existe el alumno.");
            }
        }
    }

    public void buscarAlumno(String nombre) {
        for (int i = 0; i < clase.size(); i++) {
            if (clase.get(i).getNombre().equals(nombre)) {
                System.out.println("El alumno " + nombre + " tiene una nota de " + clase.get(i).getNota());
            }else{
                System.out.println("El alumno " + nombre + " no esta matriculado.");
            }
        }
    }

    public void numeroAlumnos() {
        System.out.println("Hay " + clase.size() + " alumnos matriculados.");
    }
}
