package alumno;

public class Menu {
    public void monstrarMenu() {
        System.out.println("Introduzca una opcion.");

        System.out.println("1_ Agregar nuevo alumno.");

        System.out.println("2_ Eliminar alumno.");

        System.out.println("3_ Buscar alumno.");

        System.out.println("4- Numero de alumnos matriculados.");

        System.out.println("0_ Salir.");
    }
}
