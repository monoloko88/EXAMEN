package alianza;

public class XWing {

    private int numeroDeNaves;
    private String nombreDeNave;

    public XWing() {
        this.numeroDeNaves = 4;
        this.nombreDeNave = "X-Wing";
    }

    public void info() {
        System.out.format("| %-19s | %-8d |%n", nombreDeNave, numeroDeNaves);
    }

    public int naveAtacada() {
        return --numeroDeNaves;
    }

    public int getNumeroDeNaves() {
        return numeroDeNaves;
    }

}
