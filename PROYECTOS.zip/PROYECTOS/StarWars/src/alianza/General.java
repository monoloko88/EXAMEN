package alianza;

public class General {

    private DestructorLigero destructorLigero;
    private AWing wing;
    private XWing xWing;

    public General() {
        this.destructorLigero = new DestructorLigero();
        this.wing = new AWing();
        this.xWing = new XWing();
    }

    public void info() {
        System.out.format("+---------------------+----------+%n");
        System.out.format("|   Nombre De Nave    | Cantidad |%n");
        System.out.format("+---------------------+----------+%n");
        destructorLigero.info();
        wing.info();
        xWing.info();
        System.out.format("+---------------------+----------+%n");
    }

    public DestructorLigero getDestructorLigero() {
        return destructorLigero;
    }

    public AWing getAWing() {
        return wing;
    }

    public XWing getXWing() {
        return xWing;
    }

}
