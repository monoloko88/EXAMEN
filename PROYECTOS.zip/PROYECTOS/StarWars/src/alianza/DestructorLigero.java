package alianza;

public class DestructorLigero {

    private int numeroDeNaves;
    private String nombreDeNave;

    private int vidas;

    public DestructorLigero() {
        this.numeroDeNaves = 1;
        this.nombreDeNave = "Destructor Ligero";

        this.vidas = 4;
    }

    public void info() {
        System.out.format("| %-19s | %-8d |%n", nombreDeNave, numeroDeNaves);
    }

    public int naveAtacada() {
        vidas--;
        return (vidas > 0) ? numeroDeNaves : --numeroDeNaves;
    }

    public int getNumeroDeNaves() {
        return numeroDeNaves;
    }
    
    public int getVidas() {
    	return vidas;
    }
}
