package batalla;

import java.util.Scanner;

import alianza.General;
import imperial.Almirante;

public class ElegirPersonaje {

	private General general = new General();
	private Almirante almirante = new Almirante();

	private Scanner teclado = new Scanner(System.in);
	private int numero;
	private NumeroAleatorio numeroAleatorio = new NumeroAleatorio();

	private boolean almiranteGeneral = false;

	public void elegir() {

		menu();

		presentacion();

		jugar();

		System.out.println("Has ganado");

		System.out.println("EL JUEGO HA FINALIZADO. GRACIAS POR HABER JUGADO.");
	}

	private void jugar() {
		numeroAleatorio.setNumero();

		for (int i = 0; i < 12;) {

			do {
				System.out.println("Introduce un numero [1-10] para poder jugar.");
				// System.out.println(numeroAleatorio.getNumero());
				numero = teclado.nextInt();
			} while (numero < 1 || numero > 10);

			if (numeroAleatorio.getNumero() == numero) {
				System.out.println("Fantastico, has acertado!");
				System.out.println("Esta es la lista de las naves a las que puedo atacar:");
				if (!almiranteGeneral) {
					almirante();
				} else {
					general();
				}
				i++;
				numeroAleatorio.setNumero();
			} else {
				// System.out.println("Has fallado, el numero elegido era el: " +
				// numeroAleatorio.getNumero()
				// + ". Vuelve a intentarlo!!");
				System.out.println("Has fallado. Vuelve a intentarlo!!");
			}
		}
	}

	private void almirante() {
		if (general.getDestructorLigero().getNumeroDeNaves() > 0) {
			System.out.println("1. Destructor Ligero (" + general.getDestructorLigero().getVidas() + " vidas.)");
		} else {
			System.out.println("1. Destructor Ligero (No disponible)");
		}

		if (general.getAWing().getNumeroDeNaves() > 0) {
			System.out.println("2. A-Wing");
		} else {
			System.out.println("2. A-Wing (No disponible)");
		}

		if (general.getXWing().getNumeroDeNaves() > 0) {
			System.out.println("3. X-Wing");
		} else {
			System.out.println("3. X-Wing (No disponible)");
		}

		do {
			System.out.print("Elije tu opcion: ");
			numero = teclado.nextInt();
		} while (numero < 1 || numero > 3 || !comprobar(numero));

		System.out.println("------------------------------------------------------");

		switch (numero) {
		case 1:
			if (general.getDestructorLigero().getNumeroDeNaves() > 0) {
				System.out.println("Quedan: " + general.getDestructorLigero().naveAtacada() + " Destructor Ligero.");
			} else {
				System.out.println("No disponible");
			}
			break;
		case 2:
			System.out.println("Quedan: " + general.getAWing().naveAtacada() + " Wing.");
			break;
		case 3:
			System.out.println("Quedan: " + general.getXWing().naveAtacada() + " X-Wing.");
			break;
		default:
			break;
		}
	}

	private boolean comprobar(int numero) {
		boolean comprobacion = false;

		if (!almiranteGeneral) {
			if (general.getDestructorLigero().getNumeroDeNaves() > 0 && numero == 1
					|| general.getAWing().getNumeroDeNaves() > 0 && numero == 2
					|| general.getXWing().getNumeroDeNaves() > 0 && numero == 3) {
				comprobacion = true;
			}
		} else {
			if (almirante.getDestructorImperial().getNumeroDeNaves() > 0 && numero == 1
					|| almirante.getTieBomber().getNumeroDeNaves() > 0 && numero == 2
					|| almirante.getTieFighter().getNumeroDeNaves() > 0 && numero == 3) {
				comprobacion = true;
			}
		}
		return comprobacion;
	}

	private void general() {
		if (almirante.getDestructorImperial().getNumeroDeNaves() > 0) {
			System.out.println("1. Destructor Imperial (" + almirante.getDestructorImperial().getVidas() + " vidas.)");
		} else {
			System.out.println("1. Destructor Imperial (No disponible)");
		}

		if (almirante.getTieBomber().getNumeroDeNaves() > 0) {
			System.out.println("2. Tie Bomber");
		} else {
			System.out.println("2. Tie Bomber (No disponible)");
		}

		if (almirante.getTieFighter().getNumeroDeNaves() > 0) {
			System.out.println("3. Tie Fighter");
		} else {
			System.out.println("3. Tie Fighter (No disponible)");
		}

		do {
			System.out.print("Elije tu opcion: ");
			numero = teclado.nextInt();
		} while (numero < 1 || numero > 3 || !comprobar(numero));

		switch (numero) {
		case 1:
			System.out.println("Quedan: " + almirante.getDestructorImperial().naveAtacada() + " Destructor Imperial.");
			break;
		case 2:
			System.out.println("Quedan: " + almirante.getTieBomber().naveAtacada() + " Tie Bomber.");
			break;
		case 3:
			System.out.println("Quedan: " + almirante.getTieFighter().naveAtacada() + " Tie Figther.");
			break;
		default:
			break;
		}
	}

	private void menu() {
		System.out.println("********************************************************");
		System.out.println("                BIENVENIDO A LA BATALLA");
		System.out.println("A continuacion selecciona el personaje que quieres usar");
		System.out.println("    1. Imperio Galactico: Almirante Imperial Harkov");
		System.out.println("       2. Alianza Rebelde: General Mon Calamari");
		System.out.println("********************************************************");
		System.out.print("Elije el heroe de tu faccion: ");
		do {
			numero = teclado.nextInt();
		} while (numero != 1 && numero != 2);
	}

	private void presentacion() {
		if (numero == 1) {
			System.out.println("------------------------------------------------------");
			System.out.println("Soy el Almirante Imperial Harkov");
			System.out.println("A mi mando tengo:");
			almirante.info();
		} else {
			System.out.println("Soy el General Mon Calamari");
			System.out.println("A mi mando tengo:");
			general.info();
			almiranteGeneral = true;
		}
	}
}