package batalla;

public class ClasePrincipal {

    public static void main(String[] args) {
        ElegirPersonaje elegirPersonaje = new ElegirPersonaje();
        elegirPersonaje.elegir();
    }

}
