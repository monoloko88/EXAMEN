package batalla;

public class NumeroAleatorio {

    private int numero;

    private int generarNumero() {
        numero = (int) (Math.random() * (10)+1);
        return numero;
    }

    public int getNumero() {
        return this.numero;
    }

    public int setNumero() {
        return generarNumero();
    }
}
