package imperial;

public class TieFighter {

    private int numeroDeNaves;
    private String nombreDeNave;

    public TieFighter() {
        this.numeroDeNaves = 4;
        this.nombreDeNave = "Tie-Fighter";
    }

    public void info() {
        System.out.format("| %-19s | %-8d |%n", nombreDeNave, numeroDeNaves);
    }

    public int naveAtacada() {
        return --numeroDeNaves;
    }

    public int getNumeroDeNaves() {
        return numeroDeNaves;
    }

}
