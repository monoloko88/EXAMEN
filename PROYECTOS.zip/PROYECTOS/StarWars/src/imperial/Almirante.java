package imperial;

public class Almirante {

    private DestructorImperial destructorImperial;
    private TieBomber tieBomber;
    private TieFighter tieFighter;

    public Almirante() {
        this.destructorImperial = new DestructorImperial();
        this.tieBomber = new TieBomber();
        this.tieFighter = new TieFighter();
    }

    public void info() {
        System.out.format("+---------------------+----------+%n");
        System.out.format("|   Nombre De Nave    | Cantidad |%n");
        System.out.format("+---------------------+----------+%n");
        destructorImperial.info();
        tieBomber.info();
        tieFighter.info();
        System.out.format("+---------------------+----------+%n");
    }

    public DestructorImperial getDestructorImperial() {
        return destructorImperial;
    }

    public TieBomber getTieBomber() {
        return tieBomber;
    }

    public TieFighter getTieFighter() {
        return tieFighter;
    }

}
