package imperial;

public class TieBomber {

    private int numeroDeNaves;
    private String nombreDeNave;

    public TieBomber() {
        this.numeroDeNaves = 4;
        this.nombreDeNave = "Tie-Bomber";
    }

    public void info() {
        System.out.format("| %-19s | %-8d |%n", nombreDeNave, numeroDeNaves);
    }

    public int naveAtacada() {
        return --numeroDeNaves;
    }

    public int getNumeroDeNaves() {
        return numeroDeNaves;
    }
}
