package src.calculoArea;

public class AreaCuadradoRectangulo {
    private double area = 0;

    public void calcularAreaCuadrado(double lado) {
        area = (lado * lado);
        System.out.printf("El area del cuadrado es: %.4f%n", area);
    }

    public void calcularAreaRectangulo(double base, double altura) {
        area = (base * altura);
        System.out.printf("El area del rectangulo es: %.4f%n", area);
    }
}
