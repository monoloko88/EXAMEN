package src.calculoArea;

public class AreaCirculoTriangulo {
    private double area = 0;

    public void calcularAreaCirculo(double radio) {
        area = (Math.PI * Math.pow(radio, 2));
        System.out.printf("El area del circulo es: %.4f%n", area);
    }

    public void calcularAreaTriangulo(double base, double altura) {
        area = (base * altura) / 2;
        System.out.printf("El area del triangulo es: %.4f%n", area);
    }
}
