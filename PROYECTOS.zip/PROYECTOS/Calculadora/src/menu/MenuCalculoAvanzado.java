package src.menu;

import java.util.Scanner;

import src.calculoAvanzado.AvanzadoPotenciaRaizCuadrada;
import src.calculoAvanzado.AvanzadoSenoCosenoTangente;

public class MenuCalculoAvanzado {
    private int opcion = 0;
    private double numero = 0;
    private int angulo = 0;

    private Scanner teclado = new Scanner(System.in);

    private AvanzadoSenoCosenoTangente senoCosenoTangente = new AvanzadoSenoCosenoTangente();
    private AvanzadoPotenciaRaizCuadrada potenciaRaizCuadrada = new AvanzadoPotenciaRaizCuadrada();

    private MenuPrincipal menuPrincipal = new MenuPrincipal();

    public void menuPrincipal() {
        System.out.println("***   MENU DE CALCULO AVANZADO  ***");
        System.out.println("1. Potencia");
        System.out.println("2. Raiz Cuadrada");
        System.out.println("3. Seno");
        System.out.println("4. Coseno");
        System.out.println("5. Tangente");
        System.out.println("0. Salir");

        do {
            System.out.println("Seleccione una opcion: ");
            opcion = teclado.nextInt();
        } while (opcion < 0 || opcion > 5);

        if (opcion != 0) {
            if (opcion == 1 || opcion == 2) {
                System.out.println("Ingrese el numero: ");
                numero = teclado.nextDouble();
            } else {
                System.out.println("Ingrese el angulo: ");
                angulo = teclado.nextInt();
            }
            menu();
            menuPrincipal();
            menuPrincipal.menuPrincipal();
        }

    }

    private void menu() {
        switch (opcion) {
            case 1:
                potenciaRaizCuadrada.calcularPotencia(numero);
                break;
            case 2:
                potenciaRaizCuadrada.calcularRaizCuadrada(numero);
                break;
            case 3:
                senoCosenoTangente.calcularSeno(angulo);
                break;
            case 4:
                senoCosenoTangente.calcularCoseno(angulo);
                break;
            case 5:
                senoCosenoTangente.calcularTangente(angulo);
                break;
            case 0:
                break;
            default:
                System.out.println("Opcion no valida");
                break;
        }
    }
}
