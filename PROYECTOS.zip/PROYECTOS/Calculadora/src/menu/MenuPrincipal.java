package src.menu;

import java.util.Scanner;

public class MenuPrincipal {

    private int opcion = 0;
    private Scanner teclado = new Scanner(System.in);

    public void menuPrincipal() {
        System.out.println("*************************");
        System.out.println("*     MENU PRINCIPAL    *");
        System.out.println("*************************");
        System.out.println("1. Calcular Area de una Figura Geometrica");
        System.out.println("2. Realizar Operacion Matematica");
        System.out.println("0. Salir");

        do {
            System.out.println("Seleccione una opcion: ");
            opcion = teclado.nextInt();
        } while (opcion < 0 || opcion > 2);

        if (opcion != 0) {
            menu();
        }
    }

    private void menu() {
        switch (opcion) {
            case 1:
                MenuAreas menuAreas = new MenuAreas();
                menuAreas.menuPrincipal();
                break;
            case 2:
                System.out.println("-------------------------------------------------");
                System.out.println("Seleccione el tipo de calculo que desea realizar: ");
                System.out.println("1. Calculo Basico");
                System.out.println("2. Calculo Avanzado");
                System.out.println("0. Salir");
                opcion = teclado.nextInt();
                while (opcion < 0 || opcion > 2) {
                    System.out.println("Seleccione una opcion: ");
                    opcion = teclado.nextInt();
                }
                switch (opcion) {
                    case 1:
                        MenuCalculoBasico menuCalculoBasico = new MenuCalculoBasico();
                        menuCalculoBasico.menuPrincipal();
                        break;
                    case 2:
                        MenuCalculoAvanzado menuCalculoAvanzado = new MenuCalculoAvanzado();
                        menuCalculoAvanzado.menuPrincipal();
                        break;
                    case 0:
                        menuPrincipal();
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        break;
                }
                break;
            case 0:
                System.out.println("Gracias por usar la calculadora");
                break;
            default:
                System.out.println("Opcion no valida");
                menuPrincipal();
                break;
        }
    }
}
