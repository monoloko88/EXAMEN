package src.menu;

import java.util.Scanner;

import src.calculoArea.AreaCirculoTriangulo;
import src.calculoArea.AreaCuadradoRectangulo;

public class MenuAreas {
    private int opcion = 0;

    private Scanner teclado = new Scanner(System.in);

    private AreaCirculoTriangulo areaCirculoTriangulo = new AreaCirculoTriangulo();
    private AreaCuadradoRectangulo areaCuadradoRectangulo = new AreaCuadradoRectangulo();

    private MenuPrincipal menuPrincipal = new MenuPrincipal();

    public void menuPrincipal() {
        System.out.println("***   MENU DE AREAS   ***");
        System.out.println("1. Area de un circulo");
        System.out.println("2. Area de un triangulo");
        System.out.println("3. Area de un cuadrado");
        System.out.println("4. Area de un rectangulo");
        System.out.println("0. Salir");

        do {
            System.out.println("Seleccione una opcion: ");
            opcion = teclado.nextInt();
        } while (opcion < 0 || opcion > 4);

        if (opcion != 0) {
            menu();
            menuPrincipal();
            menuPrincipal.menuPrincipal();
        }
    }

    private void menu() {
        switch (opcion) {
            case 1:
                int radioC = 0;

                System.out.println("Ingrese el radio: ");
                radioC = teclado.nextInt();

                areaCirculoTriangulo.calcularAreaCirculo(radioC);
                break;
            case 2:
                int baseT = 0;
                int alturaT = 0;

                System.out.println("Ingrese la base: ");
                baseT = teclado.nextInt();
                System.out.println("Ingrese la altura: ");
                alturaT = teclado.nextInt();

                areaCirculoTriangulo.calcularAreaTriangulo(baseT, alturaT);
                break;
            case 3:
                int ladoC = 0;

                System.out.println("Ingrese el lado: ");
                ladoC = teclado.nextInt();

                areaCuadradoRectangulo.calcularAreaCuadrado(ladoC);
                break;
            case 4:
                int baseR = 0;
                int alturaR = 0;

                System.out.println("Ingrese la base: ");
                baseR = teclado.nextInt();
                System.out.println("Ingrese el altura: ");
                alturaR = teclado.nextInt();

                areaCuadradoRectangulo.calcularAreaRectangulo(baseR, alturaR);
                break;
            case 0:
                break;
            default:
                break;
        }
    }

}
