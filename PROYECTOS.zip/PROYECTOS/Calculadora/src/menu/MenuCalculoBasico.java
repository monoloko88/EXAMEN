package src.menu;

import java.util.Scanner;

import src.calculoBasico.BasicoSumaResta;
import src.calculoBasico.BasicoMultiplicacionDivision;

public class MenuCalculoBasico {
    private int opcion = 0;
    private double numero1 = 0;
    private double numero2 = 0;
    private Scanner teclado = new Scanner(System.in);

    private BasicoSumaResta basicoSumaResta = new BasicoSumaResta();
    private BasicoMultiplicacionDivision basicoMultiplicacionDivision = new BasicoMultiplicacionDivision();

    private MenuPrincipal menuPrincipal = new MenuPrincipal();

    public void menuPrincipal() {
        System.out.println("***   MENU DE CALCULO BASICO ***");
        System.out.println("1. Sumar");
        System.out.println("2. Restar");
        System.out.println("3. Multiplicar");
        System.out.println("4. Dividir");
        System.out.println("0. Salir");

        do {
            System.out.println("Seleccione una opcion: ");
            opcion = teclado.nextInt();
        } while (opcion < 0 || opcion > 4);

        if (opcion != 0) {
            System.out.println("Ingrese el primer numero: ");
            numero1 = teclado.nextDouble();
            System.out.println("Ingrese el segundo numero: ");
            numero2 = teclado.nextDouble();

            menu();
            menuPrincipal();
            menuPrincipal.menuPrincipal();
        }

    }

    private void menu() {
        switch (opcion) {
            case 1:
                basicoSumaResta.sumar(numero1, numero2);
                break;
            case 2:
                basicoSumaResta.restar(numero1, numero2);
                break;
            case 3:
                basicoMultiplicacionDivision.multiplicar(numero1, numero2);
                break;
            case 4:
                basicoMultiplicacionDivision.dividir(numero1, numero2);
                break;
            case 0:
                break;
            default:
                System.out.println("Opcion no valida");
                break;
        }
    }
}
