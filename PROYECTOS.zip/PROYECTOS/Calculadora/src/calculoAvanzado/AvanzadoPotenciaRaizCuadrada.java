package src.calculoAvanzado;

public class AvanzadoPotenciaRaizCuadrada {

    public void calcularPotencia(double numero) {
        int potencia = (int) Math.pow(numero, 2);
        System.out.println("La potencia del numero es: " + potencia);
    }

    public void calcularRaizCuadrada(double numero) {
        int raiz = (int) Math.sqrt(numero);
        System.out.println("La raiz cuadrada del numero es: " + raiz);
    }
}
