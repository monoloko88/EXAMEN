package src.calculoAvanzado;

public class AvanzadoSenoCosenoTangente {

    public void calcularSeno(int angulo) {
        double seno = Math.sin(angulo);
        System.out.printf("El seno del angulo es: %.4f%n", seno);
    }

    public void calcularCoseno(int angulo) {
        double coseno = Math.cos(angulo);
        System.out.printf("El coseno del angulo es: %.4f%n", coseno);
    }

    public void calcularTangente(int angulo) {
        double tangente = Math.tan(angulo);
        System.out.printf("La tangente del angulo es: %.4f%n", tangente);
    }
}
