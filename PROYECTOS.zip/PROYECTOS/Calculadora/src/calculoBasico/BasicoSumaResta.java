package src.calculoBasico;

public class BasicoSumaResta {
    private double resultado = 0;

    public void sumar(double numero1, double numero2) {
        resultado = numero1 + numero2;
        System.out.println("El resultado de la suma es: " + resultado);
    }

    public void restar(double numero1, double numero2) {
        resultado = numero1 - numero2;
        System.out.println("El resultado de la resta es: " + resultado);
    }
}
