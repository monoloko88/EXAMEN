package src.calculoBasico;

public class BasicoMultiplicacionDivision {
    private double resultado = 0;

    public void multiplicar(double numero1, double numero2) {
        resultado = (numero1 * numero2);
        System.out.println("El resultado de la multiplicacion es: " + resultado);
    }

    public void dividir(double numero1, double numero2) {
        resultado = (numero1 / numero2);
        System.out.println("El resultado de la division es: " + resultado);
    }
}
