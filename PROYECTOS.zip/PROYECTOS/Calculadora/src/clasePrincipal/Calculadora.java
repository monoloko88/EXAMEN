package src.clasePrincipal;



import src.menu.MenuPrincipal;

public class Calculadora {
    public static void main(String[] args) {
        MenuPrincipal menuPrincipal;
        menuPrincipal = new MenuPrincipal();

        menuPrincipal.menuPrincipal();
    }
}