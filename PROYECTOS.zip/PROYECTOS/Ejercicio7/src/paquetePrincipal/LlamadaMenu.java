package paquetePrincipal;

import java.util.Scanner;

import alumno.Alumno;
import alumno.FichaAlumno;
import alumno.Menu;

public class LlamadaMenu {
	private Menu menu;
	private Scanner scan = new Scanner(System.in);
	private int opcion;
	private FichaAlumno ficha = new FichaAlumno();
	private Alumno alumno;
	private String nombre;
	private int nota;

	public void llamarMenu() {
		menu = new Menu();

		do {
			System.out.print("Introducir una opcion: ");
			opcion = scan.nextInt();

			switch (opcion) {
			case 1:
				System.out.print("Introduzca el nombre del alumno: ");
				nombre = scan.next();
				System.out.print("Introduzca la nota del alumno: ");
				nota = scan.nextInt();

				ficha.add(nombre, nota);
				break;
			case 2:
				System.out.print("Introduzca el nombre del alumno: ");
				nombre = scan.next();

				ficha.delete(nombre);
				break;
			case 3:
				System.out.print("Introduzca el nombre del alumno: ");
				nombre = scan.next();
				
				alumno = ficha.find(nombre);
				
				
				if(alumno!=null) {
					System.out.println(alumno.getNombre());
					System.out.println(alumno.getNota());
					System.out.println("Se ha encontrado al alumno.");
				}else {
					System.out.println("El alumno no existe.");
				}
				break;
			case 4:
				System.out.println("Se han matriculado " + ficha.elementos() + " este curso.");
				break;

			default:
				break;
			}
			System.out.println("******************************");
			menu = new Menu();
		} while (opcion != 0);

	}

}
