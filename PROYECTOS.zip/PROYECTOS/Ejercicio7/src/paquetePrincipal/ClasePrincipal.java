package paquetePrincipal;

public class ClasePrincipal {

	public static void main(String[] args) {
		LlamadaMenu solucion = new LlamadaMenu();
		solucion.llamarMenu();
	}

}
