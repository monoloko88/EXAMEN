package alumno;

import java.util.ArrayList;

public class FichaAlumno {
	private ArrayList<Alumno> al = new ArrayList<Alumno>();
	private Alumno alumno;

	public FichaAlumno() {

	}

	public void add(String nombre, int nota) {
		alumno = new Alumno(nombre, nota);
		al.add(alumno);
	}

	public void delete(String nombre) {
		for (int i = 0; i < al.size(); i++) {
			if (nombre.equalsIgnoreCase(al.get(i).getNombre())) {
				al.remove(i);
				System.out.println("Alumno eliminado");
			}
		}
	}

	public Alumno find(String nombre) {
		for (int i = 0; i < al.size(); i++) {
			if (nombre.equalsIgnoreCase(al.get(i).getNombre())) {
				alumno = al.get(i);
			}
		}
		return alumno;
	}

	public int elementos() {
		return al.size();
	}
}