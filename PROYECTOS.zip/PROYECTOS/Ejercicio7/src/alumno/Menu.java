package alumno;

public class Menu {

	public Menu() {
		System.out.println("Introduzca una opcion.");

		System.out.println("1-. Agregar nuevo alumno.");

		System.out.println("2-. Eliminar alumno.");

		System.out.println("3-. Buscar alumno.");

		System.out.println("4-. Numero de alumnos matriculados.");

		System.out.println("0-. Salir.");
	}

}
