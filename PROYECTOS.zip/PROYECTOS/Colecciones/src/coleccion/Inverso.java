package coleccion;

import java.util.Scanner;

public class Inverso {

	Scanner teclado = new Scanner(System.in);
	int miArray[] = new int[5];

	public static void main(String[] args) {
		Inverso mostrar = new Inverso();
		mostrar.introducirDatos();
		mostrar.ordenInverso();
	}

	private void ordenInverso() {
		for (int i = miArray.length; i-- > 0;) {
			System.out.print(miArray[i] + " / ");
		}
	}

	private void introducirDatos() {
		for (int i = 0; i < miArray.length; i++) {
			System.out.println("Introducir un numero entero.");
			miArray[i] = teclado.nextInt();
		}
	}
}
