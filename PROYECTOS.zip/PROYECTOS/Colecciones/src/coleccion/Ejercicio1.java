package coleccion;

import java.util.Scanner;

public class Ejercicio1 {

	Scanner teclado = new Scanner(System.in);

	int numeros[] = new int[5];
	float mediaPositivos;
	float mediaNegativos;
	int ceros;

	public static void main(String[] args) {
		Ejercicio1 calcular = new Ejercicio1();

		calcular.leerNumeros();
		calcular.calcularPositivosNegativosCeros();
		calcular.mostrar();
	}

	private void mostrar() {
		System.out.print("La media de los positivos es: " + mediaPositivos + "\n");
		System.out.print("La media de los negativos es: " + mediaNegativos + "\n");
		System.out.print("El numero de ceros es: " + ceros + "\n");
	}

	private void calcularPositivosNegativosCeros() {
		int contadorP = 0;
		int contadorN = 0;

		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] == 0) {
				ceros++;
			} else if (numeros[i] > 0) {
				mediaPositivos += numeros[i];
				contadorP++;
			} else {
				mediaNegativos += numeros[i];
				contadorN++;
			}
		}

		mediaPositivos /= contadorP;
		if (contadorN > 0)
			mediaNegativos /= contadorN;
	}

	private void leerNumeros() {
		for (int i = 0; i < numeros.length; i++) {
			System.out.println("Introducir el numero " + (i + 1));
			numeros[i] = teclado.nextInt();
		}
	}

}
