package coleccion;

import java.util.Scanner;

public class ArraysMultidimensionales {

	private int[][] miArray01 = new int[10][10];

	private int[][] miArray02 = new int[5][5];
	private int fila = 0, columna = 0, total = miArray02.length * miArray02[1].length;
	private Scanner teclado = new Scanner(System.in);

	public void metodo01() {
		for (int i = 0; i < miArray01.length; i++) {
			for (int j = 0; j < miArray01[i].length;) {
				miArray01[i][j] = j++;
			}
		}
	}

	public void mostrar01() {
		for (int i = 0; i < miArray01.length; i++) {
			System.out.println("Array numero: [" + i + "]");
			// System.out.print("[" + i + "][0] - [" + i + "][1] - [" + i + "][2] - [" + i +
			// "][3] - [" + i + "][4] - ["
			// + i + "][5] - [" + i + "][6] - [" + i + "][7] - [" + i + "][8] - [" + i +
			// "][9]");
			// System.out.println();
			for (int j = 0; j < miArray01[i].length; j++) {

				System.out.print("   " + miArray01[i][j] + "    ");
			}
			System.out.println();
		}
	}

	public void metodo02() {
		System.out.println("A continuacion rellenaremos el array de dos dimensiones [5][5]");

		for (int[] is : miArray02) {
			for (int i : is) {
				System.out.print("Quedan " + (total--) + " numeros por introducir: ");
				i = teclado.nextInt();
			}
		}

//		for (int i = 0; i < miArray02.length; i++) {
//			for (int j = 0; j < miArray02[i].length; j++) {
//				System.out.print("Quedan " + (total--) + " numeros por introducir: ");
//				miArray02[i][j] = teclado.nextInt();
//			}
//		}
		System.out.println("Tenemos el Array completo. Muchas gracias");

		System.out.println("Introducir la direccion que quiere comprobar: [1]-[5]");

		do {
			System.out.print("Fila: ");
			fila = teclado.nextInt();
		} while (fila > 5 || fila < 1);
		do {
			System.out.print("Columna: ");
			columna = teclado.nextInt();
		} while (columna > 5 || columna < 1);

		System.out.println("En esa direccion se encuentra el numero:");
		System.out.println(miArray02[fila - 1][columna - 1]);
	}

	public void mostrar02() {
		for (int i = 0; i < miArray02.length; i++) {
			System.out.println("Array numero: [" + (i + 1) + "]");
			for (int j = 0; j < miArray02[i].length; j++) {

				System.out.print(miArray02[i][j] + "   ");
			}
			System.out.println();
		}
	}

}
