package coleccion;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Ejercicio4 {

	private Scanner scan = new Scanner(System.in);
	private int numero = 0;
	private ArrayList<Integer> miArray = new ArrayList<Integer>();

	public static void main(String[] args) {
		Ejercicio4 ejercicio = new Ejercicio4();
		ejercicio.rellenar();
		ejercicio.sumar();
	}

	private void rellenar() {
		System.out.println("Rellenar el ArrayList. [El 0 cierra la matriz].");

		do {
			System.out.print("Introduce un numero: ");
			numero = scan.nextInt();

			if (numero != 0)
				miArray.add(numero);
		} while (numero != 0);

		System.out.println("El ArrayList contiene " + miArray.size() + " elementos.");
	}

	private void sumar() {
		int suma = 0;
		/*
		 * for (int i = 0; i < miArray.size(); i++) { suma += miArray.get(i); }
		 */
		/*
		 * for (Integer n : miArray) { suma += n; }
		 */
		Iterator<Integer> it = miArray.iterator();
		while (it.hasNext()) {
			// Integer n = it.next();
			suma += it.next();
		}

		System.out.println("La suma de los elementos es: " + suma);
		System.out.println(miArray);
	}

}
