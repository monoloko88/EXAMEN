package coleccion;

public class ClasePrincipal {

	public static void main(String[] args) {
		//Arrays myA = new Arrays();
		//myA.miMetodo();
		//myA.recorrer();

		ArraysMultidimensionales multi = new ArraysMultidimensionales();
		//multi.metodo01();
		//multi.mostrar();
		
		multi.metodo02();
		multi.mostrar02();
	}

}
