package coleccion;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayLists {
	
	public static void main(String[] args) {
		ArrayList<String> palabras = new ArrayList<String>();
		ArrayList<Integer> numeros = new ArrayList<Integer>();
		
		
		numeros.add(44);
		numeros.add(34);
		numeros.add(14);
		numeros.add(46);
		numeros.add(3);
		numeros.add(32);
		numeros.add(64);
		numeros.add(3);
		numeros.add(27);
		numeros.add(99);
		numeros.add(4, 100);
		numeros.remove(0);
		numeros.set(0, 55);
		numeros.size();
		
		if(numeros.contains(34)) {
			System.out.println("El array contiene el numero 34.");
		}
		
		System.out.println("La posicion del numero 64 es: " + numeros.indexOf(64));
		System.out.println("La posicion del numero 64 empezando desde atras es: "+ numeros.lastIndexOf(64));
		
		System.out.println(numeros);
		
		
		Collections.sort(numeros);
		
		for (Integer integer : numeros) {
			System.out.println(integer);
		}
		
		
		numeros.remove(numeros.indexOf(3));
//		numeros.clear();
//		numeros.isEmpty();
//		numeros.removeAll(numeros);
		
		ArrayList copia1 = (ArrayList) numeros.clone();
		System.out.println(numeros.get(2));
		System.out.println(copia1.get(2));
		
		Object array[] = numeros.toArray();
	}

}
