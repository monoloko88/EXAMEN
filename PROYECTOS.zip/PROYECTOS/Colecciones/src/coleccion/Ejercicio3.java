package coleccion;

import java.util.Scanner;

public class Ejercicio3 {

	private Scanner teclado = new Scanner(System.in);

	private int[] tabla1 = new int[10];
	private int[] tabla2 = new int[10];
	private int[] tabla3 = new int[20];

	public static void main(String[] args) {
		Ejercicio3 calcular = new Ejercicio3();

		calcular.leerNumeros();

		calcular.ordenar();

		calcular.mostrar();
	}

	private void mostrar() {
		for (int i = 0; i < tabla3.length; i++) {
			System.out.print(tabla3[i] + " ");
		}
	}

	private void ordenar() {
		for (int i = 0; i < tabla3.length; i++) {
			if (i % 2 == 0) {
				tabla3[i] = tabla1[i / 2];
			} else {
				tabla3[i] = tabla2[i / 2];
			}
		}
	}

	private void leerNumeros() {
		for (int i = 0; i < 2; i++) {
			if (i < 1) {
				System.out.println("TABLA NUMERO: 1");
				for (int j = 0; j < tabla1.length; j++) {
					System.out.println("Introducir el numero " + (j + 1));
					tabla1[j] = teclado.nextInt();
				}
			} else {
				System.out.println("TABLA NUMERO: 2");
				for (int j = 0; j < tabla2.length; j++) {
					System.out.println("Introducir el numero " + (j + 1));
					tabla2[j] = teclado.nextInt();
				}
			}
		}
	}

}
