package coleccion;

public class Arrays {

	int miArray1[] = { 1, 2, 3, 4, 5 };
	int miArray2[] = new int[50];

	public void miMetodo() {
		System.out.println("ARRAY-2");
		for (int i = 0; i < miArray2.length; i++) {
			miArray2[i] = i + 10;
			System.out.println(miArray2[i]);
		}

		System.out.println("ARRAY-1");
		for (int i = 0; i < miArray1.length; i++) {
			if (miArray1[i] == 1) {
				System.out.println("No existe.");
			} else {
				System.out.println(miArray1[i]);
			}
		}
	}

	public void recorrer() {
		System.arraycopy(miArray1, 0, miArray2, 0, 3);
		for (int i : miArray2) {
			System.out.println(i);
		}
	}

	public void suma() {
		int suma = 0;
		for (int i : miArray1)
			suma += i;

		System.out.println(suma);
	}

}
