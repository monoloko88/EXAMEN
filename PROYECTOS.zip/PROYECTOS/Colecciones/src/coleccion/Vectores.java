package coleccion;

import java.util.Vector;

public class Vectores {

	public static void main(String[] args) {
		Vector vector1 = new Vector<>();
		//Son algo intermedio entre un Array unidimensional y un Arraylist
	}

}
