package coleccion;

import java.util.Scanner;

public class Ejercicio2 {

	private Scanner teclado = new Scanner(System.in);

	private int[] numeros;

	public static void main(String[] args) {
		Ejercicio2 calcular = new Ejercicio2();
		
		calcular.leerNumeros();
		System.out.println("**********RESULTADO**********");
		calcular.mostrar();
	}
	
	public Ejercicio2() {
		numeros  = new int[10];
	}

	private void mostrar() {
		for (int i = 0; i < numeros.length / 2; i++) {
			System.out.print(numeros[i] + " ");
			System.out.print(numeros[numeros.length - i - 1] + " ");
		}
	}

	private void leerNumeros() {
		for (int i = 0; i < numeros.length; i++) {
			System.out.println("Introducir el numero " + (i + 1));
			numeros[i] = teclado.nextInt();
		}
	}

}
